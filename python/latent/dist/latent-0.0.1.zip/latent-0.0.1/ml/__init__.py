from dl_functional import dl_functional
from dl_manual import dl_manual
from dl_subclass import dl_subclass
from lda import lda